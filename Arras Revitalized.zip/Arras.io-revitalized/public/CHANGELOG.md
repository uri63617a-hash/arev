# Update [2026-10-29]
- Trying out new collision functions
- Nerfed Undertow branch
- Buffed Triple Shot reload
- Buffed Triplet reload
- Moved some tanks to Double Helix
- Added Meiosis and Heavy Iterator

# Update [2026-10-28]
- Fixed certain necro tanks crashing the game

# Update [2026-10-28]
- Added Workshop
- Finished Prodigy
- Temporarily removed Hyperwinder

# Update [2026-10-28]
- Nerfed Split End
- Nerfed Frayed Rope
- Nerfed Slug
- Fixed Cocci self feeding bug

# Update [2026-10-06]
- Readded Jackhammer
- Actually fixed Conq
- Added Mega X-Hunter
- Added Vanguard to Ranger branch because im an idiot and forgot

# Update [2026-10-05]
- Fixed Conq branch, added Widget

# Update [2026-10-02]
- Added Popper from Trapper, finishing Trapper 3rd tier

# Update [2026-09-20]
- Game release!
- Fixed Mound and Hill
